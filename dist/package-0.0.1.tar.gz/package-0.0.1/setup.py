from setuptools import setup

setup(
    author = 'Natalia Chiara',
    author_email = 'natalia.chiara.98@gmail.com',
    description = 'Paquete de la segunda pre entrega',
    version= '0.0.1',
    name='package',
    packages=['paquete_clientes']
)